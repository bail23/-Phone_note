import tkinter as tk
from tkinter import ttk
import sqlite3

# Класс главного окна
class Main(tk.Frame):
    def __init__(self, root):
        super().__init__(root)
        self.init_main()

##############################################
    # Создание и работа с главным окном
    def init_main(self):
        toolbar = tk.Frame(bg='#d7d7d7', bd=2)
        toolbar.pack(side=tk.TOP, fill=tk.X)

############################################## КНОПКИ

        #ДОБАВИТЬ
        self.add_img = tk.PhotoImage(file='./img/add.png')
        btn_add = tk.Button(toolbar, bg='#d7d7d7', bd=1,
                            image=self.add_img, command=self.open_child)
        btn_add.pack(side=tk.LEFT)
        
############################################## СОЗДАНИЕ ТАБЛИЦЫ
        # Добавляем столбцы
        self.tree = ttk.Treeview(self, columns=('ID', 'name', 'phone', 'email'),
                                 height=45, show='headings')
        
        # Добавить параметры колонкам
        self.tree.column('ID', width=45, anchor=tk.CENTER)
        self.tree.column('name', width=300, anchor=tk.CENTER)
        self.tree.column('phone', width=150, anchor=tk.CENTER)
        self.tree.column('email', width=150, anchor=tk.CENTER)

        # Подписи колонок
        self.tree.heading('ID', text='ID')
        self.tree.heading('name', text='ФИО')
        self.tree.heading('phone', text='Телефон')
        self.tree.heading('email', text='E-mail')

        # Упаковка
        self.tree.pack(side=tk.LEFT)       
############################################## ВСЕ МЕТОДЫ

############################################## ВЫЗОВ КЛАССОВ
    # Методвызывающий окно добавления
    def open_child(self):
        Child()


##############################################
# Дочернее окно
class Child(tk.Toplevel):
    def __init__(self):
        super().__init__(root)
        self.init_child()

    def init_child(self):
        self.title('Добавить контакт')
        self.geometry('400x220')
        self.resizable(False,False)
        self.grab_set()
        self.focus_set()
##############################################



##############################################
if __name__ == '__Main__':
    root = tk.Tk()
    app = Main(root)
    root.title('Телефонная книга')
    root.geometry('645x450')
    root.resizable(False,False)
    root.configure(bg='White')
    root.mainloop()